package com.example.lat3_akb2_10116072_zhafirahsakinahbaity;

public class Galeri {
    private int gambar;
    public Galeri(int gambar){
        this.gambar = gambar;
    }


    public  int getGambar() {
        return gambar;
    }

    public void setGambar(int gambar) {
        this.gambar = gambar;
    }
}
